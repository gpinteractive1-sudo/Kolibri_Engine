#pragma once
#include <SDL2/SDL_vulkan.h>
#include <SDL2/SDL.h>
#include <vector>
#include <string>
using namespace std;

class WindowManager{


};