#pragma once

class FrameRenderer{
    private:
    int counter = 0;
    public:
    void FrameRender(double DeltaTime);
};